// const ModbusRTU = require("modbus-serial");
// const client = new ModbusRTU();

// const ipAddress = "192.168.1.23"; // Replace with your device's IP
// const port = 502;
// const unitId = 1;
// const startAddress = 0;
// const quantity = 8;
// const pollingInterval = 1000; // Poll every 1 seconds (1000 milliseconds)

// async function pollModbusData() {
//     try {
//         if (!client.isOpen) { // Check if the client is not already open
//             await client.connectTCP(ipAddress, port);
//             console.log(`✅ Connected to Modbus TCP device at ${ipAddress}:${port}`);
//             client.setID(unitId);
//         }

//         const data = await client.readDiscreteInputs(startAddress, quantity);
//         console.log(`📊 Discrete Inputs (Unit ID ${unitId}, Address ${startAddress}, Quantity ${quantity}):`, data.data);

//     } catch (err) {
//         console.error("❌ Modbus polling error:", err.message);
//         // Attempt to close and reopen connection on error to re-establish
//         if (client.isOpen) {
//             client.close();
//             console.log("Connection closed due to error. Attempting to reconnect...");
//         }
//     } finally {
//         // Schedule the next poll
//         setTimeout(pollModbusData, pollingInterval);
//     }
// }

// // Start the initial poll
// pollModbusData();

// client.on("error", (err) => {
//     console.error("❗ Modbus client error (event):", err.message);
//     if (client.isOpen) {
//         client.close();
//         console.log("Connection closed due to client error event.");
//     }
// });

const ModbusRTU = require("modbus-serial");
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const WebSocket = require('ws');

// --- Modbus Configuration ---
const client = new ModbusRTU();
const ipAddress = "192.168.1.23"; // Replace with your device's IP
const modbusPort = 502; // Modbus TCP port
const unitId = 1;
const startAddress = 0;
const quantity = 8;
const pollingInterval = 1000; // Poll every 1 second

// --- RS232 Serial Port Configuration ---
const comPort = "COM1"; // Make sure COM1 is correct (use Device Manager)
const baudRate = 9600;
let serialPort;
let parser;
let lastReceivedWeight = null; // Stores last valid RS232 weight

// --- WebSocket Server ---
const wsPort = 8080;
const wss = new WebSocket.Server({ port: wsPort });
console.log(`✅ WebSocket server started on port ${wsPort}`);

const connectedClients = new Set();

wss.on('connection', ws => {
  console.log('🟢 Client connected via WebSocket');
  connectedClients.add(ws);

  if (lastReceivedWeight !== null) {
    ws.send(JSON.stringify({ type: 'weightUpdate', value: lastReceivedWeight.toFixed(2) }));
  }

  ws.on('close', () => {
    console.log('🔴 Client disconnected from WebSocket');
    connectedClients.delete(ws);
  });

  ws.on('error', error => {
    console.error('WebSocket error:', error.message);
    connectedClients.delete(ws);
  });
});

function broadcastToClients(message) {
  connectedClients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  });
}

// --- RS232 Initialization ---
function initializeSerialPort() {
  serialPort = new SerialPort(
    { path: comPort, baudRate: baudRate },
    (err) => {
      if (err) {
        console.error("❌ Serial port open error:", err.message);
        setTimeout(initializeSerialPort, 5000); // retry
        return;
      }

      console.log(`✅ Connected to RS232 serial port ${comPort} at ${baudRate} baud.`);

      parser = serialPort.pipe(new ReadlineParser({ delimiter: '\r\n' }));

    //   parser.on('data', data => {
    //     try {
    //       const parsedWeight = parseFloat(data.trim());
    //       if (!isNaN(parsedWeight)) {
    //         lastReceivedWeight = parsedWeight;
    //         console.log(`📦 RS232 Data: ${lastReceivedWeight.toFixed(2)}`);
    //         broadcastToClients({ type: 'weightUpdate', value: lastReceivedWeight.toFixed(2) });
    //       } else {
    //         console.warn(`⚠️ Invalid RS232 Data: "${data.trim()}"`);
    //       }
    //     } catch (e) {
    //       console.error("RS232 parse error:", e.message);
    //     }
    //   });
    parser.on('data', data => {
  try {
    const match = data.match(/[-+]?[0-9]*\.?[0-9]+/); // Match a float or integer
    if (match) {
      const parsedWeight = parseFloat(match[0]);
      lastReceivedWeight = parsedWeight;
      console.log(`📦 RS232 Parsed Weight: ${lastReceivedWeight.toFixed(2)}`);
      broadcastToClients({ type: 'weightUpdate', value: lastReceivedWeight.toFixed(2) });
    } else {
      console.warn(`⚠️ Could not extract weight from RS232 data: "${data.trim()}"`);
    }
  } catch (e) {
    console.error("RS232 parse error:", e.message);
  }
});

    }
  );

  serialPort.on('error', (err) => {
    console.error("❗ Serial port error:", err.message);
    if (serialPort.isOpen) serialPort.close();
    setTimeout(initializeSerialPort, 2000); // Retry on error
  });

  serialPort.on('close', () => {
    console.log("❗ Serial port closed. Reconnecting...");
    setTimeout(initializeSerialPort, 2000);
  });
}

// --- Modbus Polling ---
async function pollModbusData() {
  try {
    if (!client.isOpen) {
      await client.connectTCP(ipAddress, { port: modbusPort });
      console.log(`✅ Connected to Modbus device at ${ipAddress}:${modbusPort}`);
      client.setID(unitId);
    }

    const data = await client.readDiscreteInputs(startAddress, quantity);
    const inputs = data.data;
    console.log("📊 Modbus Inputs:", inputs);

    const isGrossWeightSignal = inputs[1];
    const isTareWeightSignal = inputs[2];

    if (isGrossWeightSignal && lastReceivedWeight !== null) {
      console.log("🚩 Gross Weight Signal detected!");
      broadcastToClients({ type: 'signalTrigger', signal: 'gross', weight: lastReceivedWeight.toFixed(2) });
    }

    if (isTareWeightSignal && lastReceivedWeight !== null) {
      console.log("🚩 Tare Weight Signal detected!");
      broadcastToClients({ type: 'signalTrigger', signal: 'tare', weight: lastReceivedWeight.toFixed(2) });
    }

  } catch (err) {
    console.error("❌ Modbus polling error:", err.message);
    if (client.isOpen) {
      client.close();
      console.log("🔌 Modbus disconnected due to error. Will reconnect...");
    }
  } finally {
    setTimeout(pollModbusData, pollingInterval); // poll again
  }
}

// --- Start everything ---
initializeSerialPort();
pollModbusData();

client.on("error", (err) => {
  console.error("Modbus client error:", err.message);
  if (client.isOpen) {
    client.close();
    console.log("Modbus connection closed due to client error.");
  }
});
